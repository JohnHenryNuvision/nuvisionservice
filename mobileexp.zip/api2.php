<?php

$json = '{"vin":"5J6YH18544L001457","year":2004,"make":"Honda","model":"Element","windshields":[{"oemPartNumbers":["73111SCV306","73111SCVA00"],"amNumber":"FW02380GTNN","interchangeables":[]}],"interchangeables":{}}';


echo json_encode($json);

?><?php

$json = '{"vin":"5J6YH18544L001457","year":2004,"make":"Honda","model":"Element","windshields":[{"oemPartNumbers":["73111SCV306","73111SCVA00"],"amNumber":"FW02380GTNN","interchangeables":[]}],"interchangeables":{}}';


echo json_encode($json);

?><?php

$json = '{"vin":"5J6YH18544L001457","year":2004,"make":"Honda","model":"Element","windshields":[{"oemPartNumbers":["73111SCV306","73111SCVA00"],"amNumber":"FW02380GTNN","interchangeables":[]}],"interchangeables":{}}';


echo json_encode($json);

?><?php

$json = '{"vin":"5J6YH18544L001457","year":2004,"make":"Honda","model":"Element","windshields":[{"oemPartNumbers":["73111SCV306","73111SCVA00"],"amNumber":"FW02380GTNN","interchangeables":[]}],"interchangeables":{}}';


echo json_encode($json);

?>