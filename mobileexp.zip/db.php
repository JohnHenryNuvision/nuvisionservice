<?php
	$servername = "localhost";
    $username = "root";
    $password = "";
	$db="db_mobile_exp";
	$conn = mysqli_connect($servername, $username, $password,$db);
?>