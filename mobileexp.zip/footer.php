<footer class="footer_in clearfix">
        <div class="container">
            <p>© 2023 NuVision Auto Glass</p>
            <ul>
                <li><a href="#">Terms and Conditions</a></li>
                <li><a href="#" class="animated_link">Policy and Privacy</a></li>
                <li><a href="#" class="animated_link">FAQ</a></li>
                <li><a href="#" class="animated_link">Contact Us</a></li>
            </ul>
        </div>
</footer>